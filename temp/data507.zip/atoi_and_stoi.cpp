#include <bits/stdc++.h>
using namespace std;

signed main(){
    string a="75498375900000000000000000000";
    a.length();

    int ss=stoi(a);

    char ch[]="-475839750000020202020202002";
    int len=strlen(ch);

    int p=atoi(ch);
    cout<<p<<endl;

    return 0;
}