#include <bits/stdc++.h>
using namespace std;

signed main(){
    string s="78542";
    //&p[0]->p

    s[1]-'0';

    int p=stoi(s);
    cout<<p<<endl;



    // int n=s.length();
    // for (int i=0;i<n-1;i++){
    //     int a=atoi(&s[i]);
    //     // cout<<a<<' ';
    //     for (int j=i;j<n;j++){
    //         int b=atoi(&s[j]);
    //         // cout<<b<<' ';
    //         if (a>b)
    //             swap(s[i],s[j]);
    //         // if (s[i]>s[j])
    //         //     swap(s[i],s[j]);
    //     }
    // }
    // cout<<s<<endl;

    return 0;
}